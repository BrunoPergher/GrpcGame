package engtelecom.std;

import engtelecom.std.memoria.MemoriaGrpc;
import engtelecom.std.memoria.Carta;
import engtelecom.std.memoria.Jogada;
import engtelecom.std.memoria.Jogador;
import engtelecom.std.memoria.Jogo;
import io.grpc.stub.StreamObserver;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.google.protobuf.BoolValue;

public class MemoriaImpl extends MemoriaGrpc.MemoriaImplBase{
        private List<Jogador> jogadoresConectados = new ArrayList<>();



    private static final Logger logger = Logger.getLogger(MemoriaImpl.class.getName());

    @Override
    public void conectar(Jogador request, StreamObserver<BoolValue> responseObserver) {

        for (Jogador jogador : jogadoresConectados) {
            if (jogador.getId() == request.getId()) {
                // Jogador já está conectado, enviar resposta negativa
                String mensagem = "Jogador " + request.getNome() + " já está conectado";
                logger.info(mensagem);
                
                BoolValue response = BoolValue.newBuilder().setValue(false).build();
                responseObserver.onNext(response);
                responseObserver.onCompleted();
                return;
            }
        }

        jogadoresConectados.add(request);    
        String mensagem = "Jogador " + request.getNome() + " conectado";
        logger.info(mensagem);
       
        BoolValue response = BoolValue.newBuilder().setValue(true).build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();     
    }   
}
